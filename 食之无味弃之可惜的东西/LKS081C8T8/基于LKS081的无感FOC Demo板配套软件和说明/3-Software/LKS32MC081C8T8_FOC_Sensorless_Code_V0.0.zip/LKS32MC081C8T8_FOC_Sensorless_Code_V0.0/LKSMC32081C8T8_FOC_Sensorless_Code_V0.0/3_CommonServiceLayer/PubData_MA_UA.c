#include "PubData_MA_UA.h"

//STR_PubDatUAMA gS_PubDatUaToMa;
//STR_PubDatMAUA gS_PubDatMaToUa;
//////////////
