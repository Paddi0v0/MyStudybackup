
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'LK_StdPeriph' 
 * Target:  'Linko 07x Project' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "LKS32MC07x.h"



#endif /* RTE_COMPONENTS_H */
